
from pygame import *
init()


print("""
The game is about to start!
You can move the bird up and down using the arrow keys
Dodge the pipes to win
Good Luck!
""")

screen = display.set_mode((800, 600))
